package DLV;

public class DLVInvocationException extends DLVException
{
  public DLVInvocationException()
  {
  }

  public DLVInvocationException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           G:\OntoRule\implementations\LDL\lib\DLV3_0beta4.jar
 * Qualified Name:     DLV.DLVInvocationException
 * JD-Core Version:    0.5.4
 */