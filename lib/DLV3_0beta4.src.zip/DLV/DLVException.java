package DLV;

public class DLVException extends Throwable
{
  public DLVException()
  {
  }

  public DLVException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           G:\OntoRule\implementations\LDL\lib\DLV3_0beta4.jar
 * Qualified Name:     DLV.DLVException
 * JD-Core Version:    0.5.4
 */