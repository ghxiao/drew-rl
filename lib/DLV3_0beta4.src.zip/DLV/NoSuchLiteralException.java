package DLV;

public class NoSuchLiteralException extends DLVExceptionUncheked
{
  public NoSuchLiteralException()
  {
  }

  public NoSuchLiteralException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           G:\OntoRule\implementations\LDL\lib\DLV3_0beta4.jar
 * Qualified Name:     DLV.NoSuchLiteralException
 * JD-Core Version:    0.5.4
 */