package DLV.io;

import DLV.DLVExceptionUncheked;

public class LiteralIncompatibleException extends DLVExceptionUncheked
{
  public LiteralIncompatibleException()
  {
  }

  public LiteralIncompatibleException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           G:\OntoRule\implementations\LDL\lib\DLV3_0beta4.jar
 * Qualified Name:     DLV.io.LiteralIncompatibleException
 * JD-Core Version:    0.5.4
 */