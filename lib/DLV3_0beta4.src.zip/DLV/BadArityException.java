package DLV;

public class BadArityException extends DLVExceptionUncheked
{
  public BadArityException()
  {
  }

  public BadArityException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           G:\OntoRule\implementations\LDL\lib\DLV3_0beta4.jar
 * Qualified Name:     DLV.BadArityException
 * JD-Core Version:    0.5.4
 */