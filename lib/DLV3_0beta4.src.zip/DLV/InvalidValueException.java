package DLV;

public class InvalidValueException extends DLVExceptionUncheked
{
  public InvalidValueException()
  {
  }

  public InvalidValueException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           G:\OntoRule\implementations\LDL\lib\DLV3_0beta4.jar
 * Qualified Name:     DLV.InvalidValueException
 * JD-Core Version:    0.5.4
 */