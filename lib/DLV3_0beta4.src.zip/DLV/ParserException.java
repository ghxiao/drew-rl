package DLV;

public class ParserException extends DLVExceptionUncheked
{
  public ParserException()
  {
  }

  public ParserException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           G:\OntoRule\implementations\LDL\lib\DLV3_0beta4.jar
 * Qualified Name:     DLV.ParserException
 * JD-Core Version:    0.5.4
 */