package DLV;

public class DLVExceptionUncheked extends RuntimeException
{
  public DLVExceptionUncheked()
  {
  }

  public DLVExceptionUncheked(String paramString)
  {
    super(paramString);
  }
}

/* Location:           G:\OntoRule\implementations\LDL\lib\DLV3_0beta4.jar
 * Qualified Name:     DLV.DLVExceptionUncheked
 * JD-Core Version:    0.5.4
 */