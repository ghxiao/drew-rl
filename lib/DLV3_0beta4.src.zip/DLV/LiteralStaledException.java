package DLV;

public class LiteralStaledException extends DLVExceptionUncheked
{
  public LiteralStaledException()
  {
  }

  public LiteralStaledException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           G:\OntoRule\implementations\LDL\lib\DLV3_0beta4.jar
 * Qualified Name:     DLV.LiteralStaledException
 * JD-Core Version:    0.5.4
 */