package DLV;

public class JDBCException extends DLVExceptionUncheked
{
  public JDBCException()
  {
  }

  public JDBCException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           G:\OntoRule\implementations\LDL\lib\DLV3_0beta4.jar
 * Qualified Name:     DLV.JDBCException
 * JD-Core Version:    0.5.4
 */