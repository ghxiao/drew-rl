package DLV;

public class NoModelsComputed extends DLVExceptionUncheked
{
  public NoModelsComputed()
  {
  }

  public NoModelsComputed(String paramString)
  {
    super(paramString);
  }
}

/* Location:           G:\OntoRule\implementations\LDL\lib\DLV3_0beta4.jar
 * Qualified Name:     DLV.NoModelsComputed
 * JD-Core Version:    0.5.4
 */