package DLV;

public class InvalidParameterException extends DLVExceptionUncheked
{
  public InvalidParameterException()
  {
  }

  public InvalidParameterException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           G:\OntoRule\implementations\LDL\lib\DLV3_0beta4.jar
 * Qualified Name:     DLV.InvalidParameterException
 * JD-Core Version:    0.5.4
 */