package DLV;

public class TrueNegationNotSupportedException extends DLVExceptionUncheked
{
  public TrueNegationNotSupportedException()
  {
  }

  public TrueNegationNotSupportedException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           G:\OntoRule\implementations\LDL\lib\DLV3_0beta4.jar
 * Qualified Name:     DLV.TrueNegationNotSupportedException
 * JD-Core Version:    0.5.4
 */